#!usr/bin/env python

#INFO
__author__ = "Alana Ackermans"
__version__ = "0.0.1"

#LIBRARIES
import os
import generator_2
from generator_2 import passwoord_opties
from generator_2 import PasswordGenerator
from generator_2 import passwoord_lengte
from socket import *

#FUNCTIONS
def menu():
    print("dit zijn de opties: ")
    print("1. IP weergave")
    print("2. Random password generator")
    print("3. Linux update en upgrade")
    print("4. Software installatie MySQL")
    print("5. Systeem info weergave")
    print("6. Poortscanner")
    print("7. Systeem detectie")
    print("0. Exit")

def keuzes():
    keuze = int(input("welke optie wil je gebruiken?"))
    return keuze

def start_paswoord():
    passwoord_opties()
    keuze_gebruiker = int(input("geeft je keuze uit het optiemenu: "))
    gekozen_generator = PasswordGenerator(keuze_gebruiker)
    print(gekozen_generator.generate(passwoord_lengte()))

def start_ip_stuff():
    if os.name == "nt":
        os.system("ipconfig")
    else:
        os.system("ifconfig")

def start_update():
    os.system("apt update")
    os.system("apt upgrade -y")

def start_software():
    os.system("apt install mysql-server -y")
    
def start_system_info():
    if os.name == "nt":
        os.system("systeminfo")
    else:
        os.uname()
def start_poort_scanner():
    doel_ip = gethostbyname("localhost")
    print('Beginnen scannen op host: ' + doel_ip)

    for poort in range(50, 500):
        s = socket(AF_INET, SOCK_STREAM)

        conn = s.connect_ex((doel_ip, poort))
        if (conn == 0):
            print('Poort %d: OPEN' % (poort,))
        else :
            print("mislukt "+ str(poort))
        s.close()

def start_systeem_detectie():
    if os.name == "nt":
        print("je gebruikt een windows computer")
    if os.name == "unix":
        print("je gebruikt een linux computer")
#Om een nieuwe functionaliteit toe te voegen kan je hier een functie aanmaken
#MAIN FUNCTION
def main():
    program_running = True
    while program_running == True:
        menu()
        gebruiker_input = keuzes()
        if gebruiker_input == 1:
            start_ip_stuff()
        elif gebruiker_input == 2:
            start_paswoord()
        elif gebruiker_input == 3:
            start_update()
        elif gebruiker_input == 4:
            start_software()
        elif gebruiker_input == 5:
            start_system_info()
        elif gebruiker_input == 6:
            start_poort_scanner()
        elif gebruiker_input == 7:
            start_systeem_detectie()
        # hier kan je die nieuwe functie dan aanroepen
        elif gebruiker_input == 0:
            program_running = False




#START PROGRAM
if __name__ == '__main__':
    main()