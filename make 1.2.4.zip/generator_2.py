#!usr/bin/env python

#INFO
__author__ = "Alana Ackermans"
__version__ = "0.0.1"

#LIBRARIES
import string
import random


#FUNCTIONS

def passwoord_opties():
    print("dit zijn je opties: ")
    print("1. Letters, Cijfers en Leestekens")
    print("2. Letters en Cijfers")
    print("3. Letters en Leestekens")
    print("4. Cijfers en Leestekens")
    print("5. Enkel Letters")
    print("6. Enkel Cijfers")
    print("7. Enkel Leestekens")

def passwoord_lengte():
    lengte = input("hoe lang wil je je passwoord? ")
    return int(lengte)
#CLASSES
class PasswordGenerator:
    def __init__(self, passwordType):
        self.passwordType = int(passwordType)
    def generate(self,lenght):
        if self.passwordType == 1:
            genereer_passwoord = ''.join([random.choice(
                string.ascii_letters + string.digits + string.punctuation)
                for n in range(lenght)])
            return genereer_passwoord
        elif self.passwordType == 2:
            genereer_passwoord = ''.join([random.choice(
                string.ascii_letters + string.digits)
                for n in range(lenght)])
            return genereer_passwoord
        elif self.passwordType == 3:
            genereer_passwoord = ''.join([random.choice(
                string.ascii_letters + string.punctuation)
                for n in range(lenght)])
            return genereer_passwoord
        elif self.passwordType == 4:
            genereer_passwoord = ''.join([random.choice(
                string.digits + string.punctuation)
                for n in range(lenght)])
            return genereer_passwoord
        elif self.passwordType == 5:
            genereer_passwoord = ''.join([random.choice(
                string.ascii_letters)
                for n in range(lenght)])
            return genereer_passwoord
        elif self.passwordType == 6:
            genereer_passwoord = ''.join([random.choice(
                string.digits)
                for n in range(lenght)])
            return genereer_passwoord
        elif self.passwordType == 7:
            genereer_passwoord = ''.join([random.choice(
                string.punctuation)
                for n in range(lenght)])
            return genereer_passwoord


#MAIN FUNCTION
def main():
    passwoord_opties()
    keuze_gebruiker = int(input("geeft je keuze uit het optiemenu: "))
    gekozen_generator = PasswordGenerator(keuze_gebruiker)
    print(gekozen_generator.generate(passwoord_lengte()))


#START PROGRAM
if __name__ == '__main__':
    main()